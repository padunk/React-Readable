import React from 'react';

const NotFound = () => {
    return (
      <div>
        <h2>The Page you are looking for is Not Found!</h2>
      </div>
    );
}

export default NotFound;