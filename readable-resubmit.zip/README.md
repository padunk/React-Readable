# Udacity Project Readable
> A Content & Comment App

## Usage

```bash
npm install
npm start
```

This project use local server at
```bash
cd server
cd api-server
npm install
node server
```
Server will run at `http://localhost:3000`

This project was bootstrapped with [Create React App](https://github.com/facebookincubator/create-react-app).

Below you will find some information on how to perform common tasks.<br>
You can find the most recent version of this guide [here](https://github.com/facebookincubator/create-react-app/blob/master/packages/react-scripts/template/README.md).