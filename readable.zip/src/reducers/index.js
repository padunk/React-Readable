import { combineReducers } from 'redux';
import { categoryReducer } from './CategoriesReducer';
import { postsReducer, singlePostReducer } from './PostReducer';
import { commentsReducer } from './CommentReducer';

const rootReducer = combineReducers({
  categoryReducer,
  postsReducer,
  singlePostReducer,
  commentsReducer
});

export default rootReducer;
